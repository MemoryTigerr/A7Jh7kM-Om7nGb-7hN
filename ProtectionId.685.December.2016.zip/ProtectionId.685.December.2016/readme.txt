Here's the december public beta of ProtectionID version 0.6.8.5, lots of code has changed, 
some bugfixing done, and some tweaks, most of the new stuff is in the configuration settings, 
so please check through that and configure it to your needs (some settings such as hashing 
etc will be useful for some users, but some might not need it), so its quite flexible.

I hope you enjoy the new changes and addition, please read the license.txt file, for most
of you this doesnt really matter, but for some it does, as the license model changed,
thanks (as usual) to the beta testers, your help and feedback was incredibly useful.

Also theres an optional donate button, should you feel like wanting to donate towards the
further development of ProtectionID (v7 is in the works, so this version and possibly the
christmas / holiday season release may be the last version 6 public release.

Coming in the next release (possibly january) - file fragmentation report, compression report,
new scans and me finally fixing the pebrowse stuff :)

Version 7 will be quite different, but also will be a lot more flexible, and will initially be
cli based, so no gui (that will come later), along with different versions for unicode,
x86 and x64 among other things.

Suggestions, bug reports, new files to have their signatures added, false positives etc
are all welcome, just email at the usual email address protectionidteam@outlook.com

I have added the virus total report for the file, i have also (as usual) included the current
virustotal output results for this release, any detections i assure you they are false positives and i will be working on getting any detections whitelisted, but please make sure you download the ProtectionID release from the home site -> pid.gamecopyworld.com
url..

Also, if anyone wants to write a manual for ProtectionID or redesign the web page (my
html skills are non existant) please feel free to contact me too

oh, and happy holidays :)

/tippex
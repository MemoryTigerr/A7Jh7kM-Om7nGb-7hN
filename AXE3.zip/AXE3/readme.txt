-----------------------------------------------------------
                          AXE v3.4
               Copyright (c) Benjamin Peterson 2003
               Distributed and Supported by jBrowse
                      www.jbrowse.com
-----------------------------------------------------------


Thank you for trying AXE 3.


INSTALLATION
--------------
Just run the install program (installAXE.exe).  Then run AXE.exe.
Note that all you need to use AXE is the .exe file.  You can take it from one machine to another on a floppy disk and use it without installation.

REQUIREMENTS
---------------
AXE 3 has no particular requirements other than a Windows 95/98/2000/NT/ME/XP PC.  However, on the 'home' versions of Windows, some advanced functionality such as editing process heaps and physical devices will not work.

CONTACT
---------------
The jBrowse site is at http://www.jbrowse.com.  Questions and feedback about AXE 3 should go to axe@jbrowse.com.

REGISTRATION
--------------
The unregistered trial version will run for 30 days with full functionality.  After 30 days, it will go into 'read only' mode until it is registered.
To register AXE, please go to the AXE website at http://www.jbrowse.com/products/axe/register.html
It is easy and inexpensive to register AXE over the web.  It is also virtuous and honorable and increases the chance that more software like AXE will be produced.

DOCUMENTATION
-----------------
AXE's documentation is in Microsoft HTML Help format (a .chm file that is installed with AXE).  In case your computer does not have this help system, you can also view the documentation at our website.

LICENSING
----------
The license under which you use AXE 3 is found in the accompanying license.txt file.

HISTORY
----------
Version 2.1 of AXE was released in 1998 or 1999 by kahei.com.  Sadly, kahei.com stopped existing before some of the most important features (large files, physical disks, scripts, diffs) had been added to AXE.  jBrowse (http://www.jbrowse.com) revived the AXE project in 2002 with the intention of adding those things.  The result is the AXE 3 series.  We hope you like it.



The terms Windows, Windows NT, Windows 2000, Windows XP, Windows 95, Window 98 and Internet Explorer used in this document and in the rest of the AXE 3 documentation are trade marks of Microsoft Corporation. 


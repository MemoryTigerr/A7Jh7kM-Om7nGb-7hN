UnThemida 2.0

[Usage]
Just choose the file you want to unpack

[History]
12-05-2007
Version 2.0 
- VM problem fixed
- delphi problem fixed
- stack minor bug when the baseimage is not 400000

02-05-2007
Version 1.0
the first release

[known issues]
if this does not run in your PC, you might need to update your windows with MSVC 2005 Redistributable
http://www.microsoft.com/downloads/details.aspx?familyid=32bc1bee-a3f9-4c13-9c99-220b62a191ee&displaylang=en


ColdFever / AoRE
/*
 * $Revision$
 * 
 * $Date$
 * 
 * Copyright 1998-2011 Digital River, Inc. All rights reserved.
 */

#if defined(_LIB)
	#define ARMACCESS_IMPORT
#elif defined(ARMACCESS_EXPORTS)
	// #define ARMACCESS_IMPORT __declspec(dllexport)
	#define ARMACCESS_IMPORT
#else
	#define ARMACCESS_IMPORT __declspec(dllimport)
#endif

#define ARMACCESS_API ARMACCESS_IMPORT __stdcall

bool ARMACCESS_API CheckCode(const char *name, const char *code);
bool ARMACCESS_API InstallKey(const char *name, const char *code);
bool ARMACCESS_API InstallKeyLater(const char *name, const char *code);
bool ARMACCESS_API UninstallKey();
bool ARMACCESS_API VerifyKey(const char *name, const char *code);
bool ARMACCESS_API UpdateEnvironment();
bool ARMACCESS_API SetDefaultKey();
bool ARMACCESS_API IncrementCounter();
bool ARMACCESS_API ExpireCurrentKey();
int  ARMACCESS_API CopiesRunning();
bool ARMACCESS_API ChangeHardwareLock();
DWORD ARMACCESS_API GetShellProcessID();
void ARMACCESS_API ShowReminderMessage(HWND parent);
void ARMACCESS_API ShowReminderMessage2(HWND parent);
bool ARMACCESS_API ShowEnterKeyDialog(HWND parent);
bool ARMACCESS_API Timestamp(char *buffer, DWORD bufferlength);
const char* ARMACCESS_API UserLog();

// These functions are intended to be drop-in replacements for the Windows API
// function GetEnvironmentVariable. As such, they use the WINAPI calling method,
// not ARMACCESS_API.
DWORD ARMACCESS_IMPORT WINAPI GetProtectionVariableA(LPCSTR lpName, LPSTR lpBuffer, DWORD nSize);
DWORD ARMACCESS_IMPORT WINAPI GetProtectionVariableW(LPCWSTR lpName, LPWSTR lpBuffer, DWORD nSize);
#ifdef UNICODE
	#define GetProtectionVariable GetProtectionVariableW
#else
	#define GetProtectionVariable GetProtectionVariableA
#endif

// These are dummy functions for Visual BASIC testing
extern "C" void ARMACCESS_API SECUREBEGIN();
extern "C" void ARMACCESS_API SECUREBEGIN_A();
extern "C" void ARMACCESS_API SECUREBEGIN_B();
extern "C" void ARMACCESS_API SECUREBEGIN_C();
extern "C" void ARMACCESS_API SECUREBEGIN_D();
extern "C" void ARMACCESS_API SECUREBEGIN_E();
extern "C" void ARMACCESS_API SECUREBEGIN_F();
extern "C" void ARMACCESS_API SECUREBEGIN_G();
extern "C" void ARMACCESS_API SECUREBEGIN_H();
extern "C" void ARMACCESS_API SECUREBEGIN_I();
extern "C" void ARMACCESS_API SECUREBEGIN_K();
extern "C" void ARMACCESS_API SECUREEND();
extern "C" void ARMACCESS_API SECUREEND_A();
extern "C" void ARMACCESS_API SECUREEND_B();
extern "C" void ARMACCESS_API SECUREEND_C();
extern "C" void ARMACCESS_API SECUREEND_D();
extern "C" void ARMACCESS_API SECUREEND_E();
extern "C" void ARMACCESS_API SECUREEND_F();
extern "C" void ARMACCESS_API SECUREEND_G();
extern "C" void ARMACCESS_API SECUREEND_H();
extern "C" void ARMACCESS_API SECUREEND_I();
extern "C" void ARMACCESS_API SECUREEND_K();
extern "C" void ARMACCESS_API NANOBEGIN();
extern "C" void ARMACCESS_API NANOEND();


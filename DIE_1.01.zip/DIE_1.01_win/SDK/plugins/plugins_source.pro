TEMPLATE      = subdirs


SUBDIRS       = \
            SimpleExample


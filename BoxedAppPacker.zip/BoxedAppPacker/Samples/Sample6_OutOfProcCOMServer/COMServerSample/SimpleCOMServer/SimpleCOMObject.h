// SimpleCOMObject.h : Declaration of the CSimpleCOMObject

#pragma once
#include "resource.h"       // main symbols

#include "SimpleCOMServer.h"


#if defined(_WIN32_WCE) && !defined(_CE_DCOM) && !defined(_CE_ALLOW_SINGLE_THREADED_OBJECTS_IN_MTA)
#error "Single-threaded COM objects are not properly supported on Windows CE platform, such as the Windows Mobile platforms that do not include full DCOM support. Define _CE_ALLOW_SINGLE_THREADED_OBJECTS_IN_MTA to force ATL to support creating single-thread COM object's and allow use of it's single-threaded COM object implementations. The threading model in your rgs file was set to 'Free' as that is the only threading model supported in non DCOM Windows CE platforms."
#endif



// CSimpleCOMObject

class ATL_NO_VTABLE CSimpleCOMObject :
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSimpleCOMObject, &CLSID_SimpleCOMObject>,
	public IDispatchImpl<ISimpleCOMObject, &IID_ISimpleCOMObject, &LIBID_SimpleCOMServerLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:
	CSimpleCOMObject()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SIMPLECOMOBJECT)


BEGIN_COM_MAP(CSimpleCOMObject)
	COM_INTERFACE_ENTRY(ISimpleCOMObject)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()



	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}

	void FinalRelease()
	{
	}

public:

	HRESULT STDAPICALLTYPE DisplayMessageBox(BSTR strText)
	{
		::MessageBoxW(NULL, strText, L"SimpleCOMServer.SimpleCOMObject", MB_OK | MB_SYSTEMMODAL);

		return S_OK;
	}
};

OBJECT_ENTRY_AUTO(__uuidof(SimpleCOMObject), CSimpleCOMObject)

// SimpleCOMServer.cpp : Implementation of WinMain


#include "stdafx.h"
#include "resource.h"
#include "SimpleCOMServer.h"


class CSimpleCOMServerModule : public CAtlExeModuleT< CSimpleCOMServerModule >
{
public :
	DECLARE_LIBID(LIBID_SimpleCOMServerLib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_SIMPLECOMSERVER, "{EAB2752B-6AAA-4565-8BCC-A481376D9E63}")
};

CSimpleCOMServerModule _AtlModule;



//
extern "C" int WINAPI _tWinMain(HINSTANCE /*hInstance*/, HINSTANCE /*hPrevInstance*/, 
                                LPTSTR /*lpCmdLine*/, int nShowCmd)
{
    return _AtlModule.WinMain(nShowCmd);
}


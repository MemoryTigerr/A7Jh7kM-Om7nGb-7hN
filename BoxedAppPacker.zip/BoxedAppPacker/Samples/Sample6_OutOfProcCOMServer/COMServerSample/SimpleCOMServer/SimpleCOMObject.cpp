// SimpleCOMObject.cpp : Implementation of CSimpleCOMObject

#include "stdafx.h"
#include "SimpleCOMObject.h"


// CSimpleCOMObject


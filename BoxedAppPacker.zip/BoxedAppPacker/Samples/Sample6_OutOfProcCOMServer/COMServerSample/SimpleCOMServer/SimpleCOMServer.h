

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 7.00.0500 */
/* at Fri Nov 16 14:38:22 2012
 */
/* Compiler settings for .\SimpleCOMServer.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __SimpleCOMServer_h__
#define __SimpleCOMServer_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __ISimpleCOMObject_FWD_DEFINED__
#define __ISimpleCOMObject_FWD_DEFINED__
typedef interface ISimpleCOMObject ISimpleCOMObject;
#endif 	/* __ISimpleCOMObject_FWD_DEFINED__ */


#ifndef __SimpleCOMObject_FWD_DEFINED__
#define __SimpleCOMObject_FWD_DEFINED__

#ifdef __cplusplus
typedef class SimpleCOMObject SimpleCOMObject;
#else
typedef struct SimpleCOMObject SimpleCOMObject;
#endif /* __cplusplus */

#endif 	/* __SimpleCOMObject_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __ISimpleCOMObject_INTERFACE_DEFINED__
#define __ISimpleCOMObject_INTERFACE_DEFINED__

/* interface ISimpleCOMObject */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_ISimpleCOMObject;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("02981988-D0D8-4EE5-B18B-82660328FBB2")
    ISimpleCOMObject : public IDispatch
    {
    public:
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE DisplayMessageBox( 
            /* [in] */ BSTR strText) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISimpleCOMObjectVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISimpleCOMObject * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISimpleCOMObject * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISimpleCOMObject * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISimpleCOMObject * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISimpleCOMObject * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISimpleCOMObject * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISimpleCOMObject * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *DisplayMessageBox )( 
            ISimpleCOMObject * This,
            /* [in] */ BSTR strText);
        
        END_INTERFACE
    } ISimpleCOMObjectVtbl;

    interface ISimpleCOMObject
    {
        CONST_VTBL struct ISimpleCOMObjectVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISimpleCOMObject_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define ISimpleCOMObject_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define ISimpleCOMObject_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define ISimpleCOMObject_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define ISimpleCOMObject_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define ISimpleCOMObject_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define ISimpleCOMObject_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define ISimpleCOMObject_DisplayMessageBox(This,strText)	\
    ( (This)->lpVtbl -> DisplayMessageBox(This,strText) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __ISimpleCOMObject_INTERFACE_DEFINED__ */



#ifndef __SimpleCOMServerLib_LIBRARY_DEFINED__
#define __SimpleCOMServerLib_LIBRARY_DEFINED__

/* library SimpleCOMServerLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_SimpleCOMServerLib;

EXTERN_C const CLSID CLSID_SimpleCOMObject;

#ifdef __cplusplus

class DECLSPEC_UUID("0D9EC469-95BE-48E3-913C-9CB6FE5ADDF0")
SimpleCOMObject;
#endif
#endif /* __SimpleCOMServerLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long *, unsigned long            , BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserMarshal(  unsigned long *, unsigned char *, BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserUnmarshal(unsigned long *, unsigned char *, BSTR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long *, BSTR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif



// SimpleCOMClient.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#ifdef _DEBUG
#import "..\\SimpleCOMServer\\Debug\\SimpleCOMServer.tlb"
#else
#import "..\\SimpleCOMServer\\Release\\SimpleCOMServer.tlb"
#endif // _DEBUG

int _tmain(int argc, _TCHAR* argv[])
{
	CoInitialize(NULL);

	SimpleCOMServerLib::ISimpleCOMObject* pSimpleCOMObject = NULL;

	HRESULT hr = 
		CoCreateInstance(
			__uuidof(SimpleCOMServerLib::SimpleCOMObject), 
			NULL, 
			CLSCTX_ALL, 
			__uuidof(SimpleCOMServerLib::ISimpleCOMObject), 
			(void**)&pSimpleCOMObject);

	if (S_OK == hr)
	{
		BSTR text = SysAllocString(L"Hello!!! It works!");
		pSimpleCOMObject->DisplayMessageBox(text);
		SysFreeString(text);

		pSimpleCOMObject->Release();
	}

	CoUninitialize();

	return 0;
}


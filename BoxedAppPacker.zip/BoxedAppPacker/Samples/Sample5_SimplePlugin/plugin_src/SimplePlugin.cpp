// SimplePlugin.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

#include <time.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/timeb.h>

#include "..\\..\\..\\PluginAPI\\C++\\BoxedAppSDK.h"
#pragma comment(lib, "..\\..\\..\\PluginAPI\\C++\\bxsdk32.lib")

#ifdef _MANAGED
#pragma managed(push, off)
#endif

// NOTE: it's better to link C++ Runtime statically!

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
	if (DLL_PROCESS_ATTACH == ul_reason_for_call)
		// plugin startup
	{
		HANDLE hVirtualFile = 
		BoxedAppSDK_CreateVirtualFile(
			_T("1.txt"), 
			GENERIC_WRITE,
			FILE_SHARE_READ,
			NULL,
			CREATE_NEW,
			0,
			NULL
		);

		char tmpbuf[128] = "AM";
		_strtime_s(tmpbuf, 128);

		const char* szCurrentTime = "The time is: ";

		DWORD temp;
		WriteFile(hVirtualFile, szCurrentTime, strlen(szCurrentTime), &temp, NULL);
		WriteFile(hVirtualFile, tmpbuf, strlen(tmpbuf), &temp, NULL);

		CloseHandle(hVirtualFile);
	}
	else if (DLL_PROCESS_DETACH == ul_reason_for_call)
		// plugin cleanup
	{
	}

    return TRUE;
}

#ifdef _MANAGED
#pragma managed(pop)
#endif


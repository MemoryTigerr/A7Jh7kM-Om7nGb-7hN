This sample demonstrates how to pack an exe with Flash ActiveX and a flash movie.

The source application is written in Delphi (it's just an example; you can write an application
in any language: C++, C# and so on).

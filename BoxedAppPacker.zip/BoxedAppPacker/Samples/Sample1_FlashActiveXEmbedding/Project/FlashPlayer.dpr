program FlashPlayer;

uses
  Forms,
  MainUnit in 'MainUnit.pas' {Form1}, 
  ShockwaveFlashObjects_TLB;

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.Run;
end.

// Copyright (c) 2012 Virtualization Technologies Ltd.

unit BoxedAppSDK_DLL;

{$DEFINE BOXEDAPP_PAS_IS_INCLUDED}
{$DEFINE BOXEDAPP_SDK_USE_DLL}
{$I 'BoxedAppSDK.inc'}

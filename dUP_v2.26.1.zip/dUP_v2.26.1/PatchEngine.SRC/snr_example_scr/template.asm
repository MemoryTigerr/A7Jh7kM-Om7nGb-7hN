
.586p
.mmx			
.model flat, stdcall
option casemap :none

;******************************************************************************
;* INCLUDES                                                                   *
;******************************************************************************
include				\masm32\include\windows.inc
include				\masm32\include\user32.inc
include				\masm32\include\kernel32.inc
include				\masm32\include\shell32.inc
include				\masm32\include\advapi32.inc
include				\masm32\include\gdi32.inc
include				\masm32\include\comctl32.inc
include				\masm32\include\comdlg32.inc
include				\masm32\include\masm32.inc
include				\masm32\macros\macros.asm

includelib			\masm32\lib\user32.lib
includelib			\masm32\lib\kernel32.lib
includelib			\masm32\lib\shell32.lib
includelib			\masm32\lib\advapi32.lib
includelib			\masm32\lib\gdi32.lib
includelib			\masm32\lib\comctl32.lib
includelib			\masm32\lib\comdlg32.lib
includelib			\masm32\lib\masm32.lib

include				SnR_PatchEngine.asm

;******************************************************************************
;* PROTOTYPES                                                                 *
;******************************************************************************
DialogProc 			PROTO :DWORD,:DWORD,:DWORD,:DWORD
PatchFile			PROTO :DWORD

;******************************************************************************
;* DATA & CONSTANTS                                                           *
;******************************************************************************
.const
DLG_TARGETFILE			equ 101
BTN_PATCH			equ 102

PATTERNSIZE			equ sizeof SearchPattern

.data
targetfile			db "file.exe",0

SearchPattern			db 02Ah,045h,0EBh,000h,0C3h,000h,0EFh
SearchMask			db    0,   0,   0,   1,   0,   1,   0	 ;(1=Ignore Byte)

ReplacePattern			db 02Ah,000h,000h,010h,033h,0C0h,000h
ReplaceMask			db    0,   1,   1,   0,   0,   0,   1	 ;(1=Ignore Byte) 

.data?

;******************************************************************************
;* CODE                                                                       *
;******************************************************************************
.code
main:
	invoke InitCommonControls
	invoke GetModuleHandle,0
        invoke DialogBoxParam,eax,1,0,addr DialogProc,0
        
        invoke ExitProcess,0

align 16
DialogProc proc uses ebx esi edi hwnd:dword,message:dword,wparam:dword,lparam:dword
	
	mov eax,message
	.if eax==WM_INITDIALOG
	
		invoke SetDlgItemText,hwnd,DLG_TARGETFILE,addr targetfile
		
	.elseif eax==WM_COMMAND
	
		mov eax,wparam
		.if ax==BTN_PATCH
			
			invoke PatchFile,addr targetfile
			.if eax==0
				invoke MessageBox,hwnd,chr$("...patching failed!"),addr targetfile,MB_ICONEXCLAMATION
			.else
				invoke MessageBox,hwnd,chr$("...patching successfull!"),addr targetfile,MB_ICONINFORMATION
			.endif
		.endif
		
	.elseif eax==WM_CLOSE
	
		invoke EndDialog,hwnd,0
		
	.endif
	
	xor eax,eax
	ret 	                         
DialogProc endp


PatchFile proc _targetfile:dword

	LOCAL local_hFile	:DWORD
	LOCAL local_hFileMapping:DWORD
	LOCAL local_hViewOfFile :DWORD
	LOCAL local_retvalue	:DWORD
	LOCAL local_filesize	:DWORD
	
	pushad
	
	mov local_retvalue,0
	
	invoke CreateFile,_targetfile,GENERIC_READ+GENERIC_WRITE,FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL+FILE_ATTRIBUTE_HIDDEN,0
	.if eax!=INVALID_HANDLE_VALUE
	
		mov local_hFile,eax
		invoke CreateFileMapping,eax,0,PAGE_READWRITE,0,0,0
		.if eax!=NULL
		
			mov local_hFileMapping,eax
			
			invoke MapViewOfFile,eax,FILE_MAP_WRITE,0,0,0
			.if eax!=NULL
			
				mov local_hViewOfFile,eax
				
				invoke GetFileSize,local_hFile,0
				mov local_filesize,eax
				
				push 1
				push local_filesize
				push PATTERNSIZE
				push offset ReplaceMask
				push offset ReplacePattern
				push offset SearchMask
				push offset SearchPattern
				push local_hViewOfFile
				call SearchAndReplace
				
				mov local_retvalue,eax
				
				invoke UnmapViewOfFile,local_hViewOfFile
				
			.endif
			
			invoke CloseHandle,local_hFileMapping
		.endif
		
		invoke CloseHandle,local_hFile
	.endif
	
	popad
	
	mov eax,local_retvalue
	ret
PatchFile endp

end main
\masm32\bin\ml /c /coff /Cp template.asm
\masm32\bin\link /subsystem:windows /libpath:\masm32\lib template.obj resource.res

del *.obj

pause
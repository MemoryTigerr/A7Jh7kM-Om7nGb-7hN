\masm32\bin\ml /c /coff /Cp snr_patchengine.asm
\masm32\bin\link /dll /DEF:snr_patchengine.def /subsystem:windows /libpath:\masm32\lib snr_patchengine.obj

del *.obj

pause

; Example (how to use)
Local $StringToSnR = "5472306E67"
Local $sSearch = "5472??6E67"
Local $sReplace = "54726F6E67"
Local $OUT = _HexSearchAndReplace($StringToSnR, $sSearch, $sReplace)
Local $Error = @error
Local $Extended = @extended

ConsoleWrite(">       IN: " & $StringToSnR & @CRLF)
ConsoleWrite("-      OUT: " & $OUT & @CRLF)
ConsoleWrite("+ Extended: " & $Extended & @CRLF)
ConsoleWrite("!    Error: " & $Error & @CRLF & @CRLF)
MsgBox(0, "", "+        -IN: " & $StringToSnR & @CRLF & "-      OUT: " & $OUT & @CRLF & @CRLF & "+ Extended: " & $Extended & @CRLF & "!          Error: " & $Error & @CRLF)

; Eg2:
ConsoleWrite("-      OUT: " & _HexSearchAndReplace("001122330033221100", "00", "99") & @CRLF & "!    Error: " & @error & @CRLF & @CRLF)
; End Example.

; #FUNCTION# ;===============================================================================
; Name...........: _HexSearchAndReplace
; Description ...: Search and Replace Hex data.
; Syntax.........: _HexSearchAndReplace($StringToSnR, $sSearch, $sReplace)
; Parameters ....: $StringToSnR - Hex data to Search and Replace.
;                  $sSearch     - Hex to Search.
;                  $sReplace    - Hex to Replace.
; Return values .: Success - Returns Hex Replaced.
;                          - Sets @extended to Type of Return
;                  Failure - Returns the original string and sets @error to non zero
; Author ........: Danyfirex  and  Dao Van Trong - Trong.CF
;==========================================================================================
Func _HexSearchAndReplace($StringToSnR, $sSearch, $sReplace)
	Local Const $oStringToSnR = $StringToSnR
	Local $tReturn = 0, $IsBinary = 0
	If IsBinary($StringToSnR) Then $IsBinary = 1
	If (StringLeft($StringToSnR, 2) = "0x") Then
		$StringToSnR = StringTrimLeft($StringToSnR, 2)
		$tReturn = 1
	EndIf
	If (StringLeft($sSearch, 2) = "0x") Then $sSearch = StringTrimLeft($sSearch, 2)
	If (StringLeft($sSearch, 2) = "0x") Then $sReplace = StringTrimLeft($sReplace, 2)
	If (StringLen($StringToSnR) = 0) Or (StringLen($sSearch) = 0) Then Return SetError(-1, 0, $oStringToSnR);Not think to replace
	If @AutoItX64 Then Return SetError(1, 0, $StringToSnR);Dll only for 32-bit
	Local $taStrPtr = DllStructCreate("char Data[" & StringLen($StringToSnR) & "]")
	$taStrPtr.Data = $StringToSnR
	Local $spStrPtr = DllStructCreate("byte[" & StringLen($sSearch) & "]")
	Local $smStrPtr = DllStructCreate("byte[" & StringLen($sSearch) & "]")
	Local $aStr = StringSplit($sSearch, "")
	For $i = 1 To $aStr[0]
		DllStructSetData($spStrPtr, 1, Asc($aStr[$i]), $i)
		DllStructSetData($smStrPtr, 1, $aStr[$i] = "?" ? 1 : 0, $i);avoid a
	Next
	Local $rpStrPtr = DllStructCreate("byte[" & StringLen($sReplace) & "]")
	Local $tmStrPtr = DllStructCreate("byte[" & StringLen($sReplace) & "]")
	Local $aStr = StringSplit($sReplace, "")
	For $i = 1 To $aStr[0]
		DllStructSetData($rpStrPtr, 1, Asc($aStr[$i]), $i)
		DllStructSetData($tmStrPtr, 1, $aStr[$i] = "?" ? 1 : 0, $i);avoid b
	Next
	Local $_TargetAdress = DllStructGetPtr($taStrPtr)
	Local $_SearchPattern = DllStructGetPtr($spStrPtr)
	Local $_SearchMask = DllStructGetPtr($smStrPtr)
	Local $_ReplacePattern = DllStructGetPtr($rpStrPtr)
	Local $_ReplaceMask = DllStructGetPtr($tmStrPtr)
	Local $_PatternSize = DllStructGetSize($rpStrPtr)
	Local $_SearchSize = DllStructGetSize($taStrPtr)
	Local $aRep = DllCall("SNR_PatchEngine.dll", 'BYTE', 'SearchAndReplace', 'DWORD', $_TargetAdress, 'DWORD', $_SearchPattern, 'DWORD', $_SearchMask, 'DWORD', $_ReplacePattern, 'DWORD', $_ReplaceMask, 'DWORD', $_PatternSize, 'DWORD', $_SearchSize, 'DWORD', -1)
	If @error Or (Not IsArray($aRep)) Then Return SetError(@error, 0, $oStringToSnR)
	If $IsBinary <> 0 Then Return SetError(@error, 4, Binary("0x" & $taStrPtr.Data))
	If $tReturn <> 0 Then Return SetError(@error, 2, "0x" & $taStrPtr.Data)
	Return SetError(@error, 1, $taStrPtr.Data)
EndFunc   ;==>_HexSearchAndReplace

\masm32\bin\ml /c /coff snr_patchengine.asm
\masm32\bin\lib snr_patchengine.obj

pause

del snr_patchengine.obj
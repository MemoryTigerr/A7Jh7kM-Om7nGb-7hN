package droidguard.app.test;

import android.app.Application;
import android.content.Context;

/**
 * Created by Gorav on 06-Sep-17.
 * Get Context Static
 */

public class application extends Application {

    /** Create new application class,
     *  add new line (android:name=".application") to AndroidManifest.xml,
     *  (if the application class is already created, skip it.)
     */

    // Step 1
    static Context context; // Add line to application class

    @Override
    public void onCreate() {
        // Step 2
        context = getApplicationContext(); // Add line to application class

        super.onCreate();
    }

    // Step 3, Add Method to application class
    public static Context getAppContext() {
        return application.context;
    }

    // And add new class with new package "lib.geContext" with method
}

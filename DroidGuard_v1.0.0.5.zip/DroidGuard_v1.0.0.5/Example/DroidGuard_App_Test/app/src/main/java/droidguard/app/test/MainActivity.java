package droidguard.app.test;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.view.View;
import android.widget.TextView;

import lib.DGL;

public class MainActivity extends AppCompatActivity {

    TextView antiTemp, root, wel, xposed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        wel = (TextView)findViewById(R.id.textView7);
        wel.setText(new String(Base64.decode("V2VsY29tZQ==".getBytes(), Base64.DEFAULT)));
    }

    public void onCheckClick(View view) {
        switch (view.getId()) {
            case R.id.button:
                root = (TextView)findViewById(R.id.textView2);
                xposed = (TextView)findViewById(R.id.textView4);
                antiTemp = (TextView)findViewById(R.id.textView6);

                // Enable Check Root
                if (DGL.isRD()) {
                    root.setText(R.string.t); // Root detect
                } else{
                    root.setText(R.string.f); // Root not detect
                }

                // Enable Check Xposed
                if (DGL.isXD()) {
                    xposed.setText(R.string.t); // Xposed detect
                } else{
                    xposed.setText(R.string.f); // Xposed not detect
                }

                // Enable Anti-Temp
                if (DGL.isAT()) {
                    antiTemp.setText(R.string.t); // Signature verify pass
                } else{
                    antiTemp.setText(R.string.f); // Signature verify fail
                }

                break;
        }
    }
}

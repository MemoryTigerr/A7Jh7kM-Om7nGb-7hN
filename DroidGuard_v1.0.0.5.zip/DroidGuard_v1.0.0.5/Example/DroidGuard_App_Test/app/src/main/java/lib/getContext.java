package lib;

import android.content.Context;

import droidguard.app.test.application;

/**
 * Created by Gorav on 06-Sep-17.
 * Get Context
 */

public class getContext {

    public static Context getMainContext() {
        return application.getAppContext();
    }

// Add code to proguard config file

/* -keepclasseswithmembers public class lib.getContext* {
    public static android.content.Context getMainContext();
} */
}

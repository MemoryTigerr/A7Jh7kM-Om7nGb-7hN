package lib;

/**
 * Created by Gorav on 05-Sep-17.
 * You need Check Anti-Temp, Root, Xposed, Copy DGL Class and paste to your project 'lib/' package.
 * Note: Do Not Modify DGL class
 */

public class DGL {

    // Check Temp
    public static boolean isAT() {
        return true;
    }

    // Check Root
    public static boolean isRD() {
        return true;
    }

    // Check Xposed
    public static boolean isXD() {
        return true;
    }
}

// Add code to proguard config file

/* -keepclasseswithmembers public class lib.DGL* {
    public static boolean is*();
} */
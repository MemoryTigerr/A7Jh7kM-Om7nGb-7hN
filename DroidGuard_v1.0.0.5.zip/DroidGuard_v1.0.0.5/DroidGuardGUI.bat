@echo off
rem if you are running this form Crackers Kit 2018 then no need to change
rem if you are running it induvidual then rem the cd command.
rem thanks Avi_RE
cd Tools\Protector\DroidGuard_v1.0.0.5
start "DroidGuardGUI" /B javaw -Xms512m -Xmx1024m -cp DroidGuard.jar droidguard.Main


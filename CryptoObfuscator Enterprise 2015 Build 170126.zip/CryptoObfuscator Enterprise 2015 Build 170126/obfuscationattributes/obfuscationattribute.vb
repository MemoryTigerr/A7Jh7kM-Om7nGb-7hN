Imports System

Namespace CryptoObfuscatorHelper

    <AttributeUsage((AttributeTargets.Delegate Or (AttributeTargets.Parameter Or (AttributeTargets.Interface Or (AttributeTargets.Event Or (AttributeTargets.Field Or (AttributeTargets.Property Or (AttributeTargets.Method Or (AttributeTargets.Enum Or (AttributeTargets.Struct Or (AttributeTargets.Class Or AttributeTargets.Assembly)))))))))), AllowMultiple:=True, Inherited:=False)> _
    <CryptoObfuscatorHelper.Obfuscation()> _
    Public Class ObfuscationAttribute
        Inherits Attribute

        Private _applyToMembers As Boolean = True
        Private _exclude As Boolean = True
        Private _feature As String = "default"
        Private _strip As Boolean = True

        Public Property Exclude() As Boolean
            Get
                Return _exclude
            End Get
            Set(ByVal value As Boolean)
                _exclude = value
            End Set
        End Property

        Public Property Feature() As String
            Get
                Return _feature
            End Get
            Set(ByVal value As String)
                _feature = value
            End Set
        End Property

        Public Property ApplyToMembers() As Boolean
            Get
                Return _applyToMembers
            End Get
            Set(ByVal value As Boolean)
                _applyToMembers = value
            End Set
        End Property

        Public Property StripAfterObfuscation() As Boolean
            Get
                Return _strip
            End Get
            Set(ByVal value As Boolean)
                _strip = value
            End Set
        End Property

    End Class


    <AttributeUsage(AttributeTargets.Assembly, AllowMultiple:=True)> _
    Friend Class ObfuscationRuleAttribute
        Inherits Attribute

        Public Sub New()

        End Sub

        ' Following property is deprecated, use 'AdditionalPattern' property instead
        Public Property BaseClassPattern() As String
            Get
                Return _additionalPattern
            End Get
            Set(ByVal value As String)
                _additionalPattern = value
            End Set
        End Property

        Public Property AdditionalPattern() As String
            Get
                Return _additionalPattern
            End Get
            Set(ByVal value As String)
                _additionalPattern = value
            End Set
        End Property
              
        ' Following property is deprecated, use 'AdditionalPatternMatchesExactTypeOnly' property instead
        Public Property ImmediateParentOnly() As Boolean
            Get
                Return _additionalPatternMatchesExactTypeOnly
            End Get
            Set(ByVal value As Boolean)
                _additionalPatternMatchesExactTypeOnly = value
            End Set
        End Property

        Public Property AdditionalPatternMatchesExactTypeOnly() As Boolean
            Get
                Return _additionalPatternMatchesExactTypeOnly
            End Get
            Set(ByVal value As Boolean)
                _additionalPatternMatchesExactTypeOnly = value
            End Set
        End Property        
       
        Public Property AdditionalPatternAppliesTo() As AdditionalPatternAppliesTo
            Get
                Return _additionalPatternAppliesTo
            End Get
            Set(ByVal value As AdditionalPatternAppliesTo)
                _additionalPatternAppliesTo = value
            End Set
        End Property
        
        Public Property Pattern() As String
            Get
                Return _pattern
            End Get
            Set(ByVal value As String)
                _pattern = value
            End Set
        End Property
        Public Property StripAfterObfuscation() As Boolean
            Get
                Return _strip
            End Get
            Set(ByVal value As Boolean)
                _strip = value
            End Set
        End Property
        Public Property Target() As RuleTarget
            Get
                Return _target
            End Get
            Set(ByVal value As RuleTarget)
                _target = value
            End Set
        End Property
        Public Property Type() As RuleType
            Get
                Return _type
            End Get
            Set(ByVal value As RuleType)
                _type = value
            End Set
        End Property
        Public Property Visibility() As RuleVisibility
            Get
                Return _visibility
            End Get
            Set(ByVal value As RuleVisibility)
                _visibility = value
            End Set
        End Property
        
        Public Property Force() As Boolean
            Get
                Return _force
            End Get
            Set(ByVal value As Boolean)
                _force = value
            End Set
        End Property
        
        Public Property Order() As Integer
            Get
                Return _order
            End Get
            Set(ByVal value As Integer)
                _order = value
            End Set
        End Property


        Private _strip As Boolean = True
        Private _additionalPattern As String = String.Empty ' Renamed: earlier name was '_baseClassPattern'
        Private _additionalPatternMatchesExactTypeOnly As Boolean = True ' Renamed: earlier name was '_immediateParentOnly'
        Private _additionalPatternAppliesTo As AdditionalPatternAppliesTo = AdditionalPatternAppliesTo.BaseClassOfEnclosingType
        Private _pattern As String = String.Empty
        Private _target As RuleTarget = RuleTarget.None
        Private _type As RuleType = RuleType.DoNotObfuscate
        Private _visibility As RuleVisibility = RuleVisibility.All
        Private _force As Boolean = False
        Private _order As Integer = 0

    End Class

    <Flags()> _
    Friend Enum RuleTarget
        All = 63
        Classes = 1
        Events = 16
        Fields = 2
        Methods = 8
        None = 0
        Properties = 4
        Resources = 32
    End Enum

    Friend Enum RuleType
        DoNotObfuscate = 0
        Obfuscate = 1
    End Enum

    <Flags()> _
    Friend Enum RuleVisibility
        All = 31
        Internal = 8
        None = 0
        [Private] = 2
        [Protected] = 4
        ProtectedInternal = 16
        [Public] = 1
    End Enum
    
    <Flags()> _
    Friend Enum AdditionalPatternAppliesTo
        BaseClassOfEnclosingType = 0 ' Deprecated, use 'EnclosingType' instead
        SymbolType = 1
        EnclosingType = 2
        SymbolAttribute = 3
        EnclosingTypeAttribute = 4
        SymbolAssembly = 5
        SymbolAssemblyAttribute = 6
    End Enum


End Namespace



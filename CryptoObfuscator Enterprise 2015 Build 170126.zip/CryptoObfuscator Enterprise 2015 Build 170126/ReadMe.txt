Crypto Obfuscator For .Net
LogicNP Software
Support : support@ssware.com
Sales : sales@ssware.com
Feedback : feedback@ssware.com

==============
DESCRIPTION
==============
Crypto Obfuscator For .Net is a powerful and easy-to-use product for code protection and obfuscation, performance improvement and optimization and improved and simplified deployment of your .Net applications. Here are its main features:

Crypto Obfuscator Helps You To:

* Protect your code and intellectual property from hackers, crackers or competitors.
* Increase ROI for your business.
* Save time and money spent handling deployment related issues.
* Improve the performance of your application.
* Build a fast, light-weight and robust application
 
Why Do You Need Crypto Obfuscator To Protect Your .Net Assemblies

An unprotected .Net assembly is an easy target for hackers, crackers or competitors who can:

* Easily reverse-engineer your .Net code.
* Extract passwords, SQL queries, etc from strings
* Glean valuable trade secrets, algorithms
* Find security vulnerabilities
* Change product functionality.
 
Crypto Obfuscator uses a combination of the following sophisticated and advanced techniques for code protection, performance optimization and simplified deployment:

* Symbol Renaming
* Advanced Overload Renaming
* String Encryption
* Control Flow Obfuscation
* ILDASM Protection
* Advanced Tamper Detection
* Advanced Anti-Debug & Anti-Tracer Protection
* Anti-Reflection Protection
* Anti-Decompiler Protection
* Resource Encryption & Compression
* Assembly Embedding, Encryption & Compression
* Digital Watermarking For License Tracking
* Metadata Reduction
* Runtime Performance Optimizations
 
Additional Features

* Incremental Obfuscation
* Automatic Re-signing of assemblies
* Exclude/Include entities from obfuscation using Obfuscation Rules or inline Obfuscation Attributes
* Debugging Support & Stack Trace De-Obfuscation
* Visual Studio & MSBuild integration.
* Command Line Support - Integrate in your build process.
* And much more..!

=============
INSTALLATION
=============
Run the CryptoObfuscator.exe file to install Crypto Obfuscator For .Net.

===============
UNINSTALLATION
===============
Click on "Add-Remove Programs" in "Control Panel", select "Crypto Obfuscator For .Net" and click the "Add/Remove" button.

====================
PRICING INFORMATION
====================
Prices start from USD 149 only PER DEVELOPMENT LICENSE. Please visit website for details.

======================
ORDERING INFORMATION
======================
You can order by credit card, telephone, fax and mail. For detailed information on ordering, please visit www.ssware.com.

==================
LICENSE AGREEMENT
==================
See the license agreement in the help file.

=========
FEEDBACK
=========
You are welcome to send any comments , suggestions to support@ssware.com. This product is continually being developed to add new features and your feedback would be of a great help.

=====================
3rd PARTY COMPONENTS
=====================

The following 3rd party software components are used by this software:

1. Mono Cecil

 Author:
   Jb Evain (jbevain@gmail.com)

 (C) 2005 Jb Evain

 Permission is hereby granted, free of charge, to any person obtaining
 a copy of this software and associated documentation files (the
 "Software"), to deal in the Software without restriction, including
 without limitation the rights to use, copy, modify, merge, publish,
 distribute, sublicense, and/or sell copies of the Software, and to
 permit persons to whom the Software is furnished to do so, subject to
 the following conditions:

 The above copyright notice and this permission notice shall be
 included in all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 
 
 
2. HTML Redering Library
 (C) Jose Manuel Men�ndez Po� (http://www.menendezpoo.com/)
 
 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
    * Neither the name of the <ORGANIZATION> nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, 
 BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
 EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 POSSIBILITY OF SUCH DAMAGE.
 
 
 


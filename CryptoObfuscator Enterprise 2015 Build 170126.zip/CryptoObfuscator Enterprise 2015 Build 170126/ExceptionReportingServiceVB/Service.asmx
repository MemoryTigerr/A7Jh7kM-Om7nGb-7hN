<%@ WebService Language="VB" CodeBehind="~/ExceptionReportingService.vb" Class="ExceptionReportingService.ExceptionReportingServiceClass" %>

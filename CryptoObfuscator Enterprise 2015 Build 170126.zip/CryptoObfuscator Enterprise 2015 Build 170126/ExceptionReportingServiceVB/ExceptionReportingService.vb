Imports System
Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.IO
Imports System.Xml
Imports System.Data.Common
Imports System.Data.OleDb
Imports System.Data
Imports System.Net
Imports System.Net.Mail
Imports System.Collections.Generic


<WebService([Namespace]:="http://www.ssware.com/")> _
    <WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
    Public Class ExceptionReportingServiceClass
    Inherits LogicNP.CryptoObfuscator.ExceptionReportingService

    Public Sub New()
    End Sub

    Public Overrides Function OnUploadReportEx(ByVal data As String, ByVal reportid As String, ByVal projectid As String) As Boolean
        Dim ret As Boolean = MyBase.OnUploadReportEx(data, reportid, projectid)

        ' **By default, sending email is DISABLED. To enable modify settings below**
        ' Notify via email that a new exception report is available
        If ret AndAlso send_email Then
            Dim projectName As String = Nothing
            projectIDsToNames.TryGetValue(projectid, projectName)
            del.BeginInvoke(projectName, Nothing, Nothing) ' Call asynchronously      
        End If

        Return ret
    End Function

    ' Send email settings
    
    Shared ReadOnly send_email As Boolean = False ' If true, an email is sent to you whenever a new exception report is uploaded

    ' START EMAIL NOTIFICATION SETTINGS  (modify if 'send_email' above is set to 'True'
    
    Shared ReadOnly email_to_address As String = "" ' Email to which to send the notification of new exception report
    Shared ReadOnly email_from_address As String = email_to_address ' Email From address (defaults to same as 'email_to_address'
    Shared ReadOnly email_smtp_server As String = "" ' Server used for sending email
    Shared ReadOnly email_smtp_port As Integer = 25 ' Port used for sending email
    Shared ReadOnly email_smtp_username As String = "" ' Username for mail server (leave blank if not required)
    Shared ReadOnly email_smtp_password As String = "" ' password for mail server (leave blank if not required)
    Shared ReadOnly email_use_ssl As Boolean = False ' If true, SSL is used for sending email
    
    Shared ReadOnly email_subject As String = "New Exception Report Available{0}" ' Email subject, {0} = Crypto-Obfuscator project name
    Shared ReadOnly email_body As String = "Hello," & vbLf & vbLf & "A new exception report is available. You can download it from the Crypto Obfuscator UI." ' Email subject

    Shared projectIDsToNames As New Dictionary(Of String, String)()

    ' When using email notifications and using the exception reporting service for multiple projects...
    ' if you want to know the project name for which a new exception is available....
    ' fill in the project IDs and the corresponding user-friendly names below.
    ' To get Project-ID, open the .obproj file in a text editor and look for the "ID" attribute of the root "Project" XML node.
    Shared Sub New()
        projectIDsToNames("{project-id-1}") = "user-friendly name of the project"
        projectIDsToNames("{project-id-2}") = "user-friendly name of the project"
    End Sub

    ' END EMAIL NOTIFICATION SETTINGS 

    Delegate Sub SendEmailDelegate(ByVal projectName As String)
    Shared ReadOnly del As New SendEmailDelegate(AddressOf SendEmail)

    Private Shared Sub SendEmail(ByVal projectName As String)
        Try
            ' Construct message
            Dim message As New MailMessage(email_from_address, email_to_address)
            message.Subject = String.Format(email_subject, If(String.IsNullOrEmpty(projectName), "", " For " + projectName))
            message.Body = email_body

            Dim client As New SmtpClient(email_smtp_server, email_smtp_port)
            client.EnableSsl = email_use_ssl
            If String.IsNullOrEmpty(email_smtp_username) Then
                client.Credentials = New NetworkCredential()
            Else
                client.Credentials = New NetworkCredential(email_smtp_username, email_smtp_password)
            End If
            client.DeliveryMethod = SmtpDeliveryMethod.Network
            client.Send(message)
        Catch
        End Try
    End Sub


End Class



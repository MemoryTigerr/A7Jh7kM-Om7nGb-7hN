﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Reflection;

namespace MainApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnTestObfuscation_Click(object sender, EventArgs e)
        {
            MessageBox.Show("MainApp.Class1 obfuscated name: " + typeof(MainApp.Class1).Name,"MSBuild_Integration");
            MessageBox.Show("Library1.Class1 obfuscated name: " + typeof(Library1.Class1).Name, "MSBuild_Integration");
            MessageBox.Show("Library2.Class1 obfuscated name: " + typeof(Library2.Class1).Name, "MSBuild_Integration");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            using (StreamReader sr = new StreamReader(Assembly.GetExecutingAssembly().GetManifestResourceStream("MainApp.README_MSBUILD_INTEGRATION_SAMPLE.TXT")))
            {
                textBox1.Text = sr.ReadToEnd();
            }
        }
    }

    class Class1
    {
    }
}

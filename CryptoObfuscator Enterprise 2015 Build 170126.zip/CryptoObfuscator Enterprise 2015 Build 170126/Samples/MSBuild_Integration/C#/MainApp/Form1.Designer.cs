﻿namespace MainApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTestObfuscation = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnTestObfuscation
            // 
            this.btnTestObfuscation.Location = new System.Drawing.Point(12, 383);
            this.btnTestObfuscation.Name = "btnTestObfuscation";
            this.btnTestObfuscation.Size = new System.Drawing.Size(269, 65);
            this.btnTestObfuscation.TabIndex = 0;
            this.btnTestObfuscation.Text = "Test Obfuscation";
            this.btnTestObfuscation.UseVisualStyleBackColor = true;
            this.btnTestObfuscation.Click += new System.EventHandler(this.btnTestObfuscation_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 12);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(1009, 365);
            this.textBox1.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1033, 460);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnTestObfuscation);
            this.Name = "Form1";
            this.Text = "MSBuild Integration Sample";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTestObfuscation;
        private System.Windows.Forms.TextBox textBox1;
    }
}


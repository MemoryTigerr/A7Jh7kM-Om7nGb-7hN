﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using CryptoObfuscatorHelper.ExceptionReporting;
using System.IO;

namespace WebSiteExceptionReporting
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {

        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        static internal void ReportException(Exception ex)
        {
            try
            {
                // Save exception reports only when running obfuscated version
                if (CryptoObfuscatorHelper.Utils.Obfuscated)
                {
                    // Save exception report to <App_Data\ExceptionReports\{Project-ID}> folder...
                    // The Crypto Obfuscator UI expects exception reports in this folder.
                    string savePath = Path.Combine(HttpRuntime.AppDomainAppPath, "App_Data");
                    savePath = Path.Combine(savePath, "ExceptionReports");
                    savePath = Path.Combine(savePath, ExceptionHandler.ProjectID);
                    if (!Directory.Exists(savePath))
                        Directory.CreateDirectory(savePath);
                    savePath = Path.Combine(savePath, Guid.NewGuid().ToString("B") + ".exr");
                    ExceptionHandler.SaveReportToFile(ex, savePath);
                }
            }
            catch
            {
            }

        }

        protected void Application_Error(object sender, EventArgs e)
        {
            try
            {
                // Save exception reports only when running obfuscated version
                if (CryptoObfuscatorHelper.Utils.Obfuscated)
                {
                    Exception ex = Server.GetLastError().GetBaseException();
                    ReportException(ex);
                    // Clear server error so it is not propagated
                    Server.ClearError();

                    // Show error information or redirect to error page...
                }
            }
            catch
            {
            }
        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}
﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="WebSiteExceptionReporting._Default" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        This sample shows how to do exception report in ASP.Net.
        <br />
        <br />
        1. Build this project.<br />
        2. From Crypto Obfuscator, use File--&gt;Visual Studio Project Integration Wizard 
        to add obfuscation to this project.<br />
        3. Open the created .obproj file in Crypto Obfuscator.<br />
        4. Turn &#39;Exception Reporting&#39; ON and close Crypto Obfuscator.<br />
        5. Rebuild this project, this time, the resulting website assembly will be 
        obfuscated with Exception Reporting.<br />
        6. Run the website and simulate an exception below.<br />
        <br />
        See the <b>Application_Error method in the Global.asax.cs </b>file to see how to 
        handle the exception.<br />
        <br />
        <asp:Button ID="Button1" runat="server" onclick="Button1_Click" 
            Text="Simulate Exception" />
    
    </div>
    </form>
</body>
</html>

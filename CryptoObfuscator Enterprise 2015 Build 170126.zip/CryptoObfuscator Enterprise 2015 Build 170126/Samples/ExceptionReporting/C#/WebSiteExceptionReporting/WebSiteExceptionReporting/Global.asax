﻿<%@ Application Codebehind="Global.asax.cs" Inherits="WebSiteExceptionReporting.Global" Language="C#" %>

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CryptoObfuscatorHelper.ExceptionReporting;
using System.Net.Mail;
using System.Net;
using System.IO;

namespace AddCustomDataDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            // Handle the event which is raised whenever an exception is handled
            ExceptionHandler.ExceptionThrown += new ExceptionThrownEventHandler(ExceptionHandler_ExceptionThrown);

            InitializeComponent();
        }


        void ExceptionHandler_ExceptionThrown(object sender, ExceptionThrownEventArgs e)
        {
            ExceptionHandler.AddCustomData(e.Exception, "Data1", txtData1.Text);
            ExceptionHandler.AddCustomData(e.Exception, "Data2", txtData2.Text);
        }

        private void btnSimulateException_Click(object sender, EventArgs e)
        {
            // Simulate exception
            throw new Exception("The program has encountered a problem");
        }

    }
}

﻿namespace AddCustomDataDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnSimulateException = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtData1 = new System.Windows.Forms.TextBox();
            this.txtData2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnSimulateException
            // 
            this.btnSimulateException.Location = new System.Drawing.Point(15, 213);
            this.btnSimulateException.Name = "btnSimulateException";
            this.btnSimulateException.Size = new System.Drawing.Size(229, 57);
            this.btnSimulateException.TabIndex = 0;
            this.btnSimulateException.Text = "Simulate Exception";
            this.btnSimulateException.UseVisualStyleBackColor = true;
            this.btnSimulateException.Click += new System.EventHandler(this.btnSimulateException_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(632, 123);
            this.label1.TabIndex = 1;
            this.label1.Text = resources.GetString("label1.Text");
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Data #1:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 180);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Data #2:";
            // 
            // txtData1
            // 
            this.txtData1.Location = new System.Drawing.Point(93, 150);
            this.txtData1.Name = "txtData1";
            this.txtData1.Size = new System.Drawing.Size(551, 22);
            this.txtData1.TabIndex = 3;
            this.txtData1.Text = "Dummy data 1";
            // 
            // txtData2
            // 
            this.txtData2.Location = new System.Drawing.Point(93, 180);
            this.txtData2.Name = "txtData2";
            this.txtData2.Size = new System.Drawing.Size(551, 22);
            this.txtData2.TabIndex = 3;
            this.txtData2.Text = "Dummy data 2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(663, 282);
            this.Controls.Add(this.txtData2);
            this.Controls.Add(this.txtData1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSimulateException);
            this.Name = "Form1";
            this.Text = "Add Custom Data To Report Demo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSimulateException;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtData1;
        private System.Windows.Forms.TextBox txtData2;
    }
}


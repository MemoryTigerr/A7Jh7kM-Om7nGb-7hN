﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CryptoObfuscatorHelper.ExceptionReporting;
using System.Net.Mail;
using System.Net;
using System.IO;
using System.Drawing.Imaging;

namespace AttachFilesToExceptionReportDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            // Handle the event which is raised whenever an exception is handled
            ExceptionHandler.ExceptionThrown += new ExceptionThrownEventHandler(ExceptionHandler_ExceptionThrown);

            InitializeComponent();
        }


        void ExceptionHandler_ExceptionThrown(object sender, ExceptionThrownEventArgs e)
        {
            // Add the specified file to the exception report
            if (!string.IsNullOrEmpty(txtFile.Text))
                ExceptionHandler.AddBinaryDataFromFile(e.Exception, "", txtFile.Text);

            // Add the current screenshot to the exception report
            ExceptionHandler.AddBinaryDataFromScreenshot(e.Exception, "Screenshot.png");

        }

        private void btnSimulateException_Click(object sender, EventArgs e)
        {
            // Simulate exception
            throw new Exception("The program has encountered a problem");
        }

        private void btnBrowseFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Multiselect = false;
            dlg.Filter = "All Files (*.*)|*.*";
            if (dlg.ShowDialog(this) == DialogResult.OK)
            {
                txtFile.Text = dlg.FileName;
            }
        }

    }
}

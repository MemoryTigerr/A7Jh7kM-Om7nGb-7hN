﻿namespace EmailReportDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnSimulateException = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnSimulateException
            // 
            this.btnSimulateException.Location = new System.Drawing.Point(12, 118);
            this.btnSimulateException.Name = "btnSimulateException";
            this.btnSimulateException.Size = new System.Drawing.Size(229, 57);
            this.btnSimulateException.TabIndex = 0;
            this.btnSimulateException.Text = "Simulate Exception";
            this.btnSimulateException.UseVisualStyleBackColor = true;
            this.btnSimulateException.Click += new System.EventHandler(this.btnSimulateException_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(486, 95);
            this.label1.TabIndex = 1;
            this.label1.Text = resources.GetString("label1.Text");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(511, 187);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSimulateException);
            this.Name = "Form1";
            this.Text = "Email Exception Report Demo";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSimulateException;
        private System.Windows.Forms.Label label1;
    }
}


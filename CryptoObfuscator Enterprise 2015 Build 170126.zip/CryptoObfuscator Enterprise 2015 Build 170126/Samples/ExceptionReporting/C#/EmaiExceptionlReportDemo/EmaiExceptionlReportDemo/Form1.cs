﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CryptoObfuscatorHelper.ExceptionReporting;
using System.Net.Mail;
using System.Net;
using System.IO;

namespace EmailReportDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            // Handle the event which is raised whenever an exception is handled
            ExceptionHandler.ExceptionThrown += new ExceptionThrownEventHandler(ExceptionHandler_ExceptionThrown);

            InitializeComponent();
        }

        // Mail settings - CHANGE AS APPROPRIATE
        static string email_from_address = string.Empty; // Email From address 
        static string email_to_address = string.Empty; // Email To address 
        static string email_subject = "New Exception Report"; // Email subject
        static string email_smtp_server = string.Empty; // Server used for sending email
        static int email_smtp_port = 25; // Port used for sending email
        static bool email_use_ssl = false; // If true, SSL is used for sending email
        static string email_smtp_username = string.Empty; // Username for mail server (leave blank if not required)
        static string email_smtp_password = string.Empty; // password for mail server (leave blank if not required)

        static void ExceptionHandler_ExceptionThrown(object sender, ExceptionThrownEventArgs e)
        {
            try
            {
                // Create an exception report from the exception
                byte[] buffer = ExceptionHandler.SerializeReport(e.Exception);
                MemoryStream ms = new MemoryStream(buffer);

                // Construct email message
                MailMessage message = new MailMessage(email_from_address, email_to_address);
                message.Subject = email_subject;
                message.IsBodyHtml = true;
                message.Body = "The program encountered a problem. The exception report is attached.";

                // Attach the exception report
                message.Attachments.Add(new Attachment(ms, "ExceptionReport.exr"));

                // Send email message
                SmtpClient client = new SmtpClient(email_smtp_server, email_smtp_port);
                client.EnableSsl = email_use_ssl;
                if (string.IsNullOrEmpty(email_smtp_username))
                {
                    client.Credentials = new NetworkCredential();
                }
                else
                {
                    client.Credentials = new NetworkCredential(email_smtp_username, email_smtp_password);
                }
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.Send(message);

                MessageBox.Show("The program encountered an exception; exception report sent successfully via email","Email Exception Report Demo");

            }
            catch(Exception ex)
            {
                MessageBox.Show("Could not send exception report via email: " + ex.ToString(),"Email Exception Report Demo");
            }

            // set Handled to true, so that default exception handling does not take place
            e.Handled = true;
        }

        private void btnSimulateException_Click(object sender, EventArgs e)
        {
            // Simulate exception
            throw new Exception("The program has encountered a problem");
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CryptoObfuscatorHelper.ExceptionReporting;
using System.Net.Mail;
using System.Net;
using System.IO;

namespace SaveReportToFileDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            // Handle the event which is raised whenever an exception is handled
            ExceptionHandler.ExceptionThrown += new ExceptionThrownEventHandler(ExceptionHandler_ExceptionThrown);

            InitializeComponent();
        }

        static void ExceptionHandler_ExceptionThrown(object sender, ExceptionThrownEventArgs e)
        {
            try
            {
                // Save the exception report in a sub-folder in the "Application Data" system folder
                string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "SaveExceptionlReportDemo");
                if (!Directory.Exists(dir))
                    Directory.CreateDirectory(dir);
                string filename = Path.Combine(dir, Guid.NewGuid().ToString("B") + ".exr");

                // Save the report
                if(ExceptionHandler.SaveReportToFile(e.Exception,filename))
                    MessageBox.Show("The program encountered an exception - exception report saved successfully to file '" + filename + "'","Save Exception Report To File Demo");
                else
                    MessageBox.Show("Could not save exception report to file.", "Save Exception Report To File Demo");
            }
            catch(Exception ex)
            {
                MessageBox.Show("Could not save exception report to file: " + ex.ToString(), "Save Exception Report To File Demo");
            }

            // set Handled to true, so that default exception handling does not take place
            e.Handled = true;
        }

        private void btnSimulateException_Click(object sender, EventArgs e)
        {
            // Simulate exception
            throw new Exception("The program has encountered a problem");
        }

    }
}

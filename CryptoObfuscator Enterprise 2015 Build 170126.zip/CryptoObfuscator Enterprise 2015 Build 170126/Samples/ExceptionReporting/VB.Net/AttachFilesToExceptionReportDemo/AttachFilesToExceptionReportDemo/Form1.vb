﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports CryptoObfuscatorHelper.ExceptionReporting
Imports System.Net.Mail
Imports System.Net
Imports System.IO
Imports System.Drawing.Imaging
Public Class Form1
    Public Sub New()

        ' Handle the event which is raised whenever an exception is handled
        AddHandler ExceptionHandler.ExceptionThrown, AddressOf ExceptionHandler_ExceptionThrown
        InitializeComponent()

    End Sub

    Private Sub ExceptionHandler_ExceptionThrown(ByVal sender As Object, ByVal e As ExceptionThrownEventArgs)

        ' Add the specified file to the exception report
        If Not String.IsNullOrEmpty(txtFile.Text) Then
            ExceptionHandler.AddBinaryDataFromFile(e.Exception, "", txtFile.Text)
        End If

        ' Add the current screenshot to the exception report
        ExceptionHandler.AddBinaryDataFromScreenshot(e.Exception, "Screenshot.png")

    End Sub

   
    Private Sub btnSimulateException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimulateException.Click

        ' Simulate exception
        Throw New Exception("The program has encountered a problem")

    End Sub


    Private Sub btnBrowseFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseFile.Click

        Dim dlg As New OpenFileDialog()
        dlg.Multiselect = False
        dlg.Filter = "All Files (*.*)|*.*"
        If dlg.ShowDialog(Me) = DialogResult.OK Then
            txtFile.Text = dlg.FileName
        End If

    End Sub
End Class

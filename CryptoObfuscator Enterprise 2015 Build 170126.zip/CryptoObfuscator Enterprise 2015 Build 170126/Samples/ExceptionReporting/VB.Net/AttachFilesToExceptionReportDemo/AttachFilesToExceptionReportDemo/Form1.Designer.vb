﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.btnBrowseFile = New System.Windows.Forms.Button
        Me.txtFile = New System.Windows.Forms.TextBox
        Me.label2 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.btnSimulateException = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'btnBrowseFile
        '
        Me.btnBrowseFile.Location = New System.Drawing.Point(460, 133)
        Me.btnBrowseFile.Margin = New System.Windows.Forms.Padding(2)
        Me.btnBrowseFile.Name = "btnBrowseFile"
        Me.btnBrowseFile.Size = New System.Drawing.Size(27, 20)
        Me.btnBrowseFile.TabIndex = 11
        Me.btnBrowseFile.Text = "..."
        Me.btnBrowseFile.UseVisualStyleBackColor = True
        '
        'txtFile
        '
        Me.txtFile.Location = New System.Drawing.Point(42, 134)
        Me.txtFile.Margin = New System.Windows.Forms.Padding(2)
        Me.txtFile.Name = "txtFile"
        Me.txtFile.Size = New System.Drawing.Size(414, 20)
        Me.txtFile.TabIndex = 10
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(12, 137)
        Me.label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(26, 13)
        Me.label2.TabIndex = 9
        Me.label2.Text = "File:"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(10, 9)
        Me.label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(474, 116)
        Me.label1.TabIndex = 8
        Me.label1.Text = resources.GetString("label1.Text")
        '
        'btnSimulateException
        '
        Me.btnSimulateException.Location = New System.Drawing.Point(42, 174)
        Me.btnSimulateException.Margin = New System.Windows.Forms.Padding(2)
        Me.btnSimulateException.Name = "btnSimulateException"
        Me.btnSimulateException.Size = New System.Drawing.Size(172, 46)
        Me.btnSimulateException.TabIndex = 7
        Me.btnSimulateException.Text = "Simulate Exception"
        Me.btnSimulateException.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(497, 229)
        Me.Controls.Add(Me.btnBrowseFile)
        Me.Controls.Add(Me.txtFile)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.btnSimulateException)
        Me.Name = "Form1"
        Me.Text = "Attach Files To Exception Report Demo"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents btnBrowseFile As System.Windows.Forms.Button
    Private WithEvents txtFile As System.Windows.Forms.TextBox
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents btnSimulateException As System.Windows.Forms.Button

End Class

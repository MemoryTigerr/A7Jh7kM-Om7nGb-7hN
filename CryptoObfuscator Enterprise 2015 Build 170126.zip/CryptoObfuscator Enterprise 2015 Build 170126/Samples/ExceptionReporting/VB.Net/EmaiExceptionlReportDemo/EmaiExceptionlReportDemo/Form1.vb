﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports CryptoObfuscatorHelper.ExceptionReporting
Imports System.Net.Mail
Imports System.Net
Imports System.IO
Public Class Form1

    Public Sub New()
        ' Handle the event which is raised whenever an exception is handled
        AddHandler ExceptionHandler.ExceptionThrown, AddressOf ExceptionHandler_ExceptionThrown

        InitializeComponent()
    End Sub

    ' Mail settings - CHANGE AS APPROPRIATE
    Shared email_from_address As String = String.Empty  ' Email From address 
    Shared email_to_address As String = String.Empty    ' Email To address 
    Shared email_subject As String = "New Exception Report" ' Email subject
    Shared email_smtp_server As String = String.Empty   ' Server used for sending email
    Shared email_smtp_port As Integer = 25  ' Port used for sending email
    Shared email_use_ssl As Boolean = False ' If true, SSL is used for sending email
    Shared email_smtp_username As String = String.Empty ' Username for mail server (leave blank if not required)
    Shared email_smtp_password As String = String.Empty ' password for mail server (leave blank if not required)

    Private Shared Sub ExceptionHandler_ExceptionThrown(ByVal sender As Object, ByVal e As ExceptionThrownEventArgs)
        Try
            ' Create an exception report from the exception
            Dim buffer As Byte() = ExceptionHandler.SerializeReport(e.Exception)
            Dim ms As New MemoryStream(buffer)

            ' Construct email message
            Dim message As New MailMessage(email_from_address, email_to_address)
            message.Subject = email_subject
            message.IsBodyHtml = True
            message.Body = "The program encountered a problem. The exception report is attached."

            ' Attach the exception report
            message.Attachments.Add(New Attachment(ms, "ExceptionReport.exr"))

            ' Send email message
            Dim client As New SmtpClient(email_smtp_server, email_smtp_port)
            client.EnableSsl = email_use_ssl
            If String.IsNullOrEmpty(email_smtp_username) Then
                client.Credentials = New NetworkCredential()
            Else
                client.Credentials = New NetworkCredential(email_smtp_username, email_smtp_password)
            End If
            client.DeliveryMethod = SmtpDeliveryMethod.Network
            client.Send(message)

            MessageBox.Show("The program encountered an exception; exception report sent successfully via email", "Email Exception Report Demo")
        Catch ex As Exception
            MessageBox.Show("Could not send exception report via email: " + ex.ToString(), "Email Exception Report Demo")
        End Try

        ' set Handled to true, so that default exception handling does not take place
        e.Handled = True
    End Sub

    Private Sub btnSimulateException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimulateException.Click
        ' Simulate exception
        Throw New Exception("The program has encountered a problem")
    End Sub
End Class

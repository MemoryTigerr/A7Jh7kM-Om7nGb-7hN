﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.label1 = New System.Windows.Forms.Label
        Me.btnSimulateException = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(9, 9)
        Me.label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(364, 77)
        Me.label1.TabIndex = 3
        Me.label1.Text = resources.GetString("label1.Text")
        '
        'btnSimulateException
        '
        Me.btnSimulateException.Location = New System.Drawing.Point(9, 98)
        Me.btnSimulateException.Margin = New System.Windows.Forms.Padding(2)
        Me.btnSimulateException.Name = "btnSimulateException"
        Me.btnSimulateException.Size = New System.Drawing.Size(172, 46)
        Me.btnSimulateException.TabIndex = 2
        Me.btnSimulateException.Text = "Simulate Exception"
        Me.btnSimulateException.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(383, 152)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.btnSimulateException)
        Me.Name = "Form1"
        Me.Text = "Save Exception Report To File Demo"
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents btnSimulateException As System.Windows.Forms.Button

End Class

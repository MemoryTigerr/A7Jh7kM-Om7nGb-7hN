﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports CryptoObfuscatorHelper.ExceptionReporting
Imports System.Net.Mail
Imports System.Net
Imports System.IO

Public Class Form1
    Public Sub New()
        ' Handle the event which is raised whenever an exception is handled
        AddHandler ExceptionHandler.ExceptionThrown, AddressOf ExceptionHandler_ExceptionThrown

        InitializeComponent()
    End Sub

    Private Shared Sub ExceptionHandler_ExceptionThrown(ByVal sender As Object, ByVal e As ExceptionThrownEventArgs)
        Try
            ' Save the exception report in a sub-folder in the "Application Data" system folder
            Dim dir As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "SaveExceptionlReportDemo")
            If Not Directory.Exists(dir) Then
                Directory.CreateDirectory(dir)
            End If
            Dim filename As String = Path.Combine(dir, Guid.NewGuid().ToString("B") + ".exr")

            ' Save the report
            If ExceptionHandler.SaveReportToFile(e.Exception, filename) Then
                MessageBox.Show("The program encountered an exception - exception report saved successfully to file '" + filename + "'", "Save Exception Report To File Demo")
            Else
                MessageBox.Show("Could not save exception report to file.", "Save Exception Report To File Demo")
            End If
        Catch ex As Exception
            MessageBox.Show("Could not save exception report to file: " + ex.ToString(), "Save Exception Report To File Demo")
        End Try

        ' set Handled to true, so that default exception handling does not take place
        e.Handled = True
    End Sub

    Private Sub btnSimulateException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimulateException.Click
        ' Simulate exception
        Throw New Exception("The program has encountered a problem")
    End Sub
End Class

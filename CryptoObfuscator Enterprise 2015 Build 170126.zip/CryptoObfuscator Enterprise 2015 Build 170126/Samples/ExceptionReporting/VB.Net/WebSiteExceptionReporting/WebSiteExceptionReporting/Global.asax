﻿<%@ Application Codebehind="Global.asax.vb" Inherits="WebSiteExceptionReporting.Global_asax" Language="vb" %>

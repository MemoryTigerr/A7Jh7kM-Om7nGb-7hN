﻿Imports System.Web.SessionState
Imports CryptoObfuscatorHelper.ExceptionReporting
Imports System.IO

Public Class Global_asax
    Inherits System.Web.HttpApplication

    Sub Application_Start(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the application is started
    End Sub

    Sub Session_Start(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the session is started
    End Sub

    Sub Application_BeginRequest(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires at the beginning of each request
    End Sub

    Sub Application_AuthenticateRequest(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires upon attempting to authenticate the use
    End Sub

    Friend Shared Sub ReportException(ByVal ex As Exception)

        Try
            ' Save exception reports only when running obfuscated version
            If CryptoObfuscatorHelper.Utils.Obfuscated Then
                ' Save exception report to <App_Data\ExceptionReports\{Project-ID}> folder...
                ' The Crypto Obfuscator UI expects exception reports in this folder.
                Dim savePath As String = Path.Combine(HttpRuntime.AppDomainAppPath, "App_Data")
                savePath = Path.Combine(savePath, "ExceptionReports")
                savePath = Path.Combine(savePath, ExceptionHandler.ProjectID)
                If Not Directory.Exists(savePath) Then
                    Directory.CreateDirectory(savePath)
                End If
                savePath = Path.Combine(savePath, Guid.NewGuid().ToString("B") + ".exr")
                ExceptionHandler.SaveReportToFile(ex, savePath)
            End If
        Catch
        End Try

    End Sub

    Sub Application_Error(ByVal sender As Object, ByVal e As EventArgs)

        Try
            ' Save exception reports only when running obfuscated version
            If CryptoObfuscatorHelper.Utils.Obfuscated Then
                Dim ex As Exception = Server.GetLastError().GetBaseException()
                ReportException(ex)
                ' Clear server error so it is not propagated

                ' Show error information or redirect to error page...
                Server.ClearError()
            End If
        Catch
        End Try

    End Sub

    Sub Session_End(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the session ends
    End Sub

    Sub Application_End(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the application ends
    End Sub

End Class
﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports CryptoObfuscatorHelper.ExceptionReporting
Imports System.Net.Mail
Imports System.Net
Imports System.IO

Public Class Form1

    Public Sub New()
        ' Handle the event which is raised whenever an exception is handled
        AddHandler ExceptionHandler.ExceptionThrown, AddressOf ExceptionHandler_ExceptionThrown

        InitializeComponent()
    End Sub

    Private Sub ExceptionHandler_ExceptionThrown(ByVal sender As Object, ByVal e As ExceptionThrownEventArgs)
        ExceptionHandler.AddCustomData(e.Exception, "Data1", txtData1.Text)
        ExceptionHandler.AddCustomData(e.Exception, "Data2", txtData2.Text)
    End Sub

    Private Sub btnSimulateException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimulateException.Click
        ' Simulate exception
        Throw New Exception("The program has encountered a problem")
    End Sub
End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.txtData2 = New System.Windows.Forms.TextBox
        Me.txtData1 = New System.Windows.Forms.TextBox
        Me.label3 = New System.Windows.Forms.Label
        Me.label2 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.btnSimulateException = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'txtData2
        '
        Me.txtData2.Location = New System.Drawing.Point(72, 147)
        Me.txtData2.Margin = New System.Windows.Forms.Padding(2)
        Me.txtData2.Name = "txtData2"
        Me.txtData2.Size = New System.Drawing.Size(414, 20)
        Me.txtData2.TabIndex = 8
        Me.txtData2.Text = "Dummy data 2"
        '
        'txtData1
        '
        Me.txtData1.Location = New System.Drawing.Point(72, 123)
        Me.txtData1.Margin = New System.Windows.Forms.Padding(2)
        Me.txtData1.Name = "txtData1"
        Me.txtData1.Size = New System.Drawing.Size(414, 20)
        Me.txtData1.TabIndex = 9
        Me.txtData1.Text = "Dummy data 1"
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Location = New System.Drawing.Point(11, 147)
        Me.label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(49, 13)
        Me.label3.TabIndex = 7
        Me.label3.Text = "Data #2:"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(11, 123)
        Me.label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(49, 13)
        Me.label2.TabIndex = 6
        Me.label2.Text = "Data #1:"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(11, 8)
        Me.label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(474, 100)
        Me.label1.TabIndex = 5
        Me.label1.Text = resources.GetString("label1.Text")
        '
        'btnSimulateException
        '
        Me.btnSimulateException.Location = New System.Drawing.Point(13, 174)
        Me.btnSimulateException.Margin = New System.Windows.Forms.Padding(2)
        Me.btnSimulateException.Name = "btnSimulateException"
        Me.btnSimulateException.Size = New System.Drawing.Size(172, 46)
        Me.btnSimulateException.TabIndex = 4
        Me.btnSimulateException.Text = "Simulate Exception"
        Me.btnSimulateException.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(497, 229)
        Me.Controls.Add(Me.txtData2)
        Me.Controls.Add(Me.txtData1)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.btnSimulateException)
        Me.Name = "Form1"
        Me.Text = "Add Custom Data To Report Demo"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents txtData2 As System.Windows.Forms.TextBox
    Private WithEvents txtData1 As System.Windows.Forms.TextBox
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents btnSimulateException As System.Windows.Forms.Button

End Class

using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.IO;
using System.Xml;
using System.Data.Common;
using System.Data.OleDb;
using System.Data;
using System.Net.Mail;
using System.Net;
using System.Collections.Generic;

namespace ExceptionReportingService
{
    [WebService(Namespace = "http://www.ssware.com/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class ExceptionReportingServiceClass : LogicNP.CryptoObfuscator.ExceptionReportingService
    {
        public ExceptionReportingServiceClass()
        {
        }

        public override bool OnUploadReportEx(string data, string reportid, string projectid)
        {
            bool ret = base.OnUploadReportEx(data, reportid, projectid);

            // **By default, sending email is DISABLED. To enable modify settings below**
            // Notify via email that a new exception report is available
            if (ret && send_email)
            {
                string projectName = null;
                projectIDsToNames.TryGetValue(projectid, out projectName);
                del.BeginInvoke(projectName, null, null); // Call asynchronously
            }

            return ret;            
        }

        // Send email settings
        static readonly bool send_email = false; // If true, an email is sent to you whenever a new exception report is uploaded

        // START EMAIL NOTIFICATION SETTINGS  (modify if 'send_email' above is set to 'true'

        static readonly string email_to_address = ""; // Email to which to send the notification of new exception report
        static readonly string email_from_address = email_to_address; // Email From address (defaults to same as 'email_to_address'
        static readonly string email_smtp_server = ""; // Server used for sending email
        static readonly int email_smtp_port = 25; // Port used for sending email
        static readonly string email_smtp_username = ""; // Username for mail server (leave blank if not required)
        static readonly string email_smtp_password = ""; // password for mail server (leave blank if not required)
        static readonly bool email_use_ssl = false; // If true, SSL is used for sending email
        
        static readonly string email_subject = "New Exception Report Available{0}"; // Email subject, {0} = Crypto-Obfuscator project name
        static readonly string email_body = "Hello,\n\nA new exception report is available. You can download it from the Crypto Obfuscator UI."; // Email subject

        // When using email notifications and using the exception reporting service for multiple projects...
        // if you want to know the project name for which a new exception is available....
        // fill in the project IDs and the corresponding user-friendly names below.
        // To get Project-ID, open the .obproj file in a text editor and look for the "ID" attribute of the root "Project" XML node.
        static Dictionary<string, string> projectIDsToNames = new Dictionary<string, string>()
        {
            // {"{project-id-1}","user-friendly name of the project"},
            // {"{project-id-2}","user-friendly name of the project"},
        };

        // END EMAIL NOTIFICATION SETTINGS


        delegate void SendEmailDelegate(string projectName);
        static readonly SendEmailDelegate del = new SendEmailDelegate(SendEmail);

        static void SendEmail(string projectName)
        {
            try
            {
                // Construct message
                MailMessage message = new MailMessage(email_from_address, email_to_address);
                message.Subject = string.Format(email_subject, string.IsNullOrEmpty(projectName) ? "" : " For " + projectName);
                message.Body = email_body;

                SmtpClient client = new SmtpClient(email_smtp_server, email_smtp_port);
                client.EnableSsl = email_use_ssl;
                if (string.IsNullOrEmpty(email_smtp_username))
                {
                    client.Credentials = new NetworkCredential();
                }
                else
                {
                    client.Credentials = new NetworkCredential(email_smtp_username, email_smtp_password);
                }
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.Send(message);
            }
            catch { }
        }

    }

}
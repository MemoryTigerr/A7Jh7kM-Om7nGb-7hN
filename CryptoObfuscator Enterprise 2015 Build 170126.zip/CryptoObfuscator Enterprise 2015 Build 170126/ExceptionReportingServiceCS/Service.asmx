<%@ WebService Language="C#" CodeBehind="~/ExceptionReportingService.cs" Class="ExceptionReportingService.ExceptionReportingServiceClass" %>
